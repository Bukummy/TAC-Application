package com.example.android.slidingtabsbasic.AppContent;

public class TechKeyList extends TechCategoryList{

    @Override
    String getTableName() {
        return "key";
    }
}
